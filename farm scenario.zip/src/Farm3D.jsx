
import { Canvas } from "@react-three/fiber";

const fruitCrops = [
  "Mango", "Orange", "Apple", "Lemon", "Guava",
  "Coconut", "Grape", "Strawberry", "Papaya",
  "Banana", "Pineapple"
];

const leafyCrops = [
  "Tomato", "Pepper", "Cucumber", "Cabbage",
  "Spinach", "Lettuce", "Okra"
];

const rootCrops = [
  "Carrot", "Potato", "Sweet Potato", "Cassava",
  "Yam", "Ginger", "Turmeric", "Onion"
];

const lowCrops = [
  "Beans", "Groundnut", "Soybean", "Pea",
  "Cowpea", "Sesame", "Sunflower"
];

function Ground({ soilType }) {
  const soilColors = {
    Sandy: "#C2A16B",
    Clay: "#8B5E3C",
    Loamy: "#654321",
    Silt: "#8A8060",
  };

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]}>
      <planeGeometry args={[12, 12]} />
      <meshStandardMaterial
        color={soilColors[soilType] || "#654321"}
      />
    </mesh>
  );
}

function CropPlant({
  position,
  selectedCrop,
  scenario,
  soilType,
  waterAvailability,
}) {
  const isDrought = scenario === "Drought";
  const isIrrigated = scenario === "Drought + Irrigation";
const waterPercent = Number.parseFloat(
  String(waterAvailability ?? "").replace("%", "").trim()
);
const isWaterStressed =
  Number.isFinite(waterPercent) && waterPercent < 35;
  const stemColor =
  isDrought || isWaterStressed ? "#9A8244" : "#43843B";

const leafColor =
  isDrought || isWaterStressed ? "#B7A34A" : "#55A630";
  const fruitColor = "#E9A23B";

  const isFruit = fruitCrops.includes(selectedCrop);
  const isLeafy = leafyCrops.includes(selectedCrop);
  const isRoot = rootCrops.includes(selectedCrop);
  const isLow = lowCrops.includes(selectedCrop);
const plantScale = isWaterStressed ? 0.75 : 1;
const plantHealthColor = isWaterStressed ? "#B7A34A" : leafColor;
  return (
   <group position={position} scale={plantScale}>
      {/* Fruit trees */}
      {isFruit && (
        <>
          <mesh position={[0, 0.65, 0]}>
            <cylinderGeometry args={[0.1, 0.14, 1.3, 8]} />
            <meshStandardMaterial color="#795438" />
          </mesh>

          {[
  [-0.35, 1.3, 0],
  [0.3, 1.35, 0.1],
  [0, 1.65, 0],
  [-0.1, 1.45, 0.3],
  [0.15, 1.5, -0.25],
].map((p, i) => (
  <mesh
  key={i}
  position={p}
  scale={[1.15, 0.85, 1]}
>
    <sphereGeometry args={[0.42, 12, 10]} />
    <meshStandardMaterial
      color={leafColor}
      roughness={0.85}
    />
  </mesh>
))}

          {selectedCrop !== "Coconut" &&
            selectedCrop !== "Grape" &&
            [[-0.25, 1.3, 0.35], [0.25, 1.55, -0.2]].map((p, i) => (
              <mesh key={i} position={p}>
               <sphereGeometry args={[0.42, 12, 10]} />
                <meshStandardMaterial color={fruitColor} />
              </mesh>
            ))}

          {selectedCrop === "Coconut" &&
            [0, 1, 2].map((i) => (
              <mesh
                key={i}
                position={[
                  Math.cos(i * 2.1) * 0.25,
                  1.65,
                  Math.sin(i * 2.1) * 0.25,
                ]}
              >
                <sphereGeometry args={[0.13, 8, 8]} />
                <meshStandardMaterial color="#795438" />
              </mesh>
            ))}
        </>
      )}

      {/* Leafy vegetables and fruiting vegetables */}
      {isLeafy && (
        <>
          <mesh position={[0, 0.3, 0]}>
            <cylinderGeometry args={[0.07, 0.1, 0.6, 8]} />
            <meshStandardMaterial color={stemColor} />
          </mesh>

          {Array.from({ length: 5 }, (_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos(i * 1.26) * 0.23,
                0.4 + (i % 2) * 0.12,
                Math.sin(i * 1.26) * 0.23,
              ]}
              rotation={[0.25, i, -0.3]}
            >
              <sphereGeometry args={[0.25, 8, 6]} />
              <meshStandardMaterial color={leafColor} />
            </mesh>
          ))}

          {(selectedCrop === "Tomato" ||
            selectedCrop === "Pepper").toString() === "true" && (
            <mesh position={[0.16, 0.48, 0.08]}>
              <sphereGeometry args={[0.12, 8, 8]} />
              <meshStandardMaterial color="#D94735" />
            </mesh>
          )}
        </>
      )}

      {/* Root and tuber crops */}
      {isRoot && (
        <>
          <mesh position={[0, 0.12, 0]}>
            <sphereGeometry args={[0.24, 8, 6]} />
            <meshStandardMaterial color="#A77B43" />
          </mesh>

          {[-0.2, 0, 0.2].map((x, i) => (
            <mesh
              key={i}
              position={[x, 0.38 + (i % 2) * 0.12, 0]}
              rotation={[0, 0, x * 1.5]}
            >
              <coneGeometry args={[0.14, 0.48, 6]} />
              <meshStandardMaterial color={leafColor} />
            </mesh>
          ))}
        </>
      )}

      {/* Beans, groundnuts and other low-growing crops */}
      {isLow && (
        <>
          {[-0.18, 0, 0.18].map((x, i) => (
            <mesh
              key={i}
              position={[x, 0.28 + (i % 2) * 0.1, 0]}
              rotation={[0, 0, x * 2]}
            >
              <sphereGeometry args={[0.24, 8, 6]} />
              <meshStandardMaterial color={leafColor} />
            </mesh>
          ))}
          {selectedCrop === "Sunflower" && (
            <mesh position={[0, 0.85, 0]}>
              <sphereGeometry args={[0.2, 8, 8]} />
              <meshStandardMaterial color="#E8B52F" />
            </mesh>
          )}
        </>
      )}

      {/* Tall cereal crops and other crops without a special model */}
      {!isFruit && !isLeafy && !isRoot && !isLow && (
        <>
          <mesh position={[0, 0.65, 0]}>
            <cylinderGeometry args={[0.055, 0.09, 1.3, 8]} />
            <meshStandardMaterial color={stemColor} />
          </mesh>

          {[-1, 1].map((side) => (
            <mesh
              key={side}
              position={[side * 0.2, 0.75, 0]}
              rotation={[0, 0, side * -0.5]}
            >
              <boxGeometry args={[0.48, 0.07, 0.12]} />
              <meshStandardMaterial color={leafColor} />
            </mesh>
          ))}

          <mesh position={[0, 1.38, 0]}>
            <sphereGeometry args={[0.15, 8, 6]} />
            <meshStandardMaterial
              color={isDrought ? "#B7A34A" : "#D5B64B"}
            />
          </mesh>
        </>
      )}

      {/* Irrigation indicator beside each plant */}
      {isIrrigated && (
        <mesh position={[0.35, 0.08, 0]}>
          <sphereGeometry args={[0.07, 8, 6]} />
          <meshStandardMaterial color="#2589D8" />
        </mesh>
      )}
    </group>
  );
}

function MangoTree({ leafColor, fruitColor, isWaterStressed }) {
  const leaves = [
    [-0.65, 1.75, 0.05, -0.65],
    [-0.35, 2.05, 0.2, 0.4],
    [0.05, 2.15, -0.25, -0.2],
    [0.45, 1.95, 0.1, 0.7],
    [0.7, 1.7, -0.1, -0.5],
    [-0.15, 1.75, 0.45, 0.8],
    [0.25, 1.7, -0.4, -0.7],
    [-0.45, 1.55, -0.3, 0.3],
    [0.5, 1.55, 0.35, -0.4],
    [0, 2.4, 0, 0.2],
    [-0.7, 1.95, -0.2, 0.5],
    [0.65, 2.15, 0.25, -0.3],
  ];

  const branches = [
    [-0.22, 1.05, 0, 0.45],
    [0.2, 1.25, 0, -0.45],
    [-0.28, 1.45, 0, 0.65],
    [0.25, 1.55, 0, -0.65],
  ];

  const mangoes = [
    [-0.48, 1.48, 0.12],
    [0.42, 1.55, 0.08],
    [0.12, 1.78, 0.3],
    [-0.18, 1.88, -0.22],
  ];

  return (
    <group>
      {/* Main trunk */}
      <mesh position={[0, 0.75, 0]}>
        <cylinderGeometry args={[0.09, 0.17, 1.5, 10]} />
        <meshStandardMaterial color="#765033" roughness={1} />
      </mesh>

      {/* Branches */}
      {branches.map(([x, y, z, angle], i) => (
        <mesh
          key={`branch-${i}`}
          position={[x * 0.65, y, z]}
          rotation={[0, 0, angle]}
        >
          <cylinderGeometry args={[0.035, 0.065, 0.72, 7]} />
          <meshStandardMaterial color="#765033" roughness={1} />
        </mesh>
      ))}

      {/* Individual elongated mango leaves */}
      {leaves.map(([x, y, z, angle], i) => (
        <mesh
          key={`leaf-${i}`}
          position={[x, y, z]}
          rotation={[0.15, angle * 0.4, angle]}
          scale={isWaterStressed ? [0.8, 0.8, 0.8] : [1, 1, 1]}
        >
          <sphereGeometry args={[0.19, 8, 6]} />
          <meshStandardMaterial
            color={leafColor}
            roughness={0.82}
          />
        </mesh>
      ))}

      {/* Hanging mango fruits */}
      {!isWaterStressed &&
        mangoes.map(([x, y, z], i) => (
          <mesh
            key={`mango-${i}`}
            position={[x, y, z]}
            rotation={[0, 0, x * 0.8]}
            scale={[0.75, 1.15, 0.7]}
          >
            <sphereGeometry args={[0.105, 12, 10]} />
            <meshStandardMaterial
              color={fruitColor || "#E9A23B"}
              roughness={0.48}
            />
          </mesh>
        ))}
    </group>
  );
}

function IrrigationSystem() {
  return (
    <group>
      <mesh position={[0, 0.08, 0]}>
        <boxGeometry args={[6, 0.12, 0.18]} />
        <meshStandardMaterial color="#2589D8" />
      </mesh>

      {[-2, 0, 2].map((x) => (
        <mesh key={x} position={[x, 0.2, 0]}>
          <cylinderGeometry args={[0.06, 0.06, 0.3, 8]} />
          <meshStandardMaterial color="#2589D8" />
        </mesh>
      ))}
    </group>
  );
}

function FarmScene({
  selectedCrop,
  soilType,
  scenario,
  waterAvailability = "74%",
  plantCount = 6,
}) {
  

const positions = Array.from(
  { length: plantCount },
  (_, index) => {
    const columns = 3;
    const spacing = 1.5;
    const rows = Math.ceil(plantCount / columns);

    return [
      (index % columns) * spacing -
        ((Math.min(plantCount, columns) - 1) * spacing) / 2,
      0,
      Math.floor(index / columns) * spacing -
        ((rows - 1) * spacing) / 2,
    ];
  }
);
  return (
    <>
      <ambientLight intensity={1.5} />
      <directionalLight position={[5, 8, 5]} intensity={2} />

      <Ground soilType={soilType} />

      {scenario === "Drought + Irrigation" && <IrrigationSystem />}

      {positions.map((position, index) => (
  <CropPlant
    key={`${selectedCrop}-${index}`}
    position={position}
    selectedCrop={selectedCrop}
    scenario={scenario}
    soilType={soilType}
waterAvailability={waterAvailability}
/>
))}
    </>
  );
}

export default function Farm3D({
  selectedCrop = "Maize",
  soilType = "Sandy",
  scenario = "Normal",
  waterAvailability = "74%",
  plantCount = 6,
}) {
  return (
    <div
      style={{
        width: "100%",
        height: "450px",
        borderRadius: "16px",
        overflow: "hidden",
        background: "#87CEEB",
      }}
    >
      <Canvas camera={{ position: [7, 6, 8], fov: 50 }}>
        <FarmScene
  selectedCrop={selectedCrop}
  soilType={soilType}
  scenario={scenario}
  waterAvailability={waterAvailability}
  plantCount={plantCount}
/>
    </Canvas>
    </div>
  );
}
